# -*- coding: utf-8 -*-

neutral = [
    'Abrese o elevador e hai un programador dentro. Preguntanlle: Sube ou baixa? O programador respondelle: - Si',
    'Que lle di un bit a outro? Vemonos no bus.',
    'Atracador: Os cartos ou a vida! Programador: Sintoo, son programador. Atracador: E? Programador: Non posuo nin cartos nin vida.',
    'Que e un terapeuta? - 1024 gigapeutas',
    'Cantos programadores fan falta para cambiar unha lampada? - Ningun, e un problema de hardware.',
    'Abrese o pano, aparece un informatico e di: Que tocachedes que o pano non se cerra!',
    'Falece unha persoa mentres estudaba na biblioteca. - Que estaba a estudar? - A API de Windows',
    'Que lle di un GIF a un PNG? - Animate, home...',
    'Que berra un informatico que se esta a afogar na praia? F1, F1!',
    'So hay 10 tipos de persoas no mundo, aquelas que entenden binario e as que non',
    'So hay 10 tipos de persoas no mundo, as que entenden trinario, as que non, e as que o confunden co binario.',
    'Unha muller dixo o seu home: - Ve a tenda e trae unha barra de pan, e, se hai ovos, doce. Volveu con doce barras de pan.',
    'Podese saber quen demonios e o General Failure? Esta tratando de ler o meu disco duro.',
    'En que se diferencian Windows e un virus? En que o virus funciona, e e gratis.'
]

jokes_gl = {
    'neutral': neutral,
    'all': neutral,
}
